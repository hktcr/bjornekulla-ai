# ALL PROMPTS WITH EXPECTED OUTCOMES

This document contains all 16 prompts used in the workshop, with expected outcomes, troubleshooting, and context.

---

## FILM 1: What is a virtual expert panel?

### Prompt 1: Panel WITHOUT Coordinator (shows loss of control)

**Film:** 1 - What is a virtual expert panel?
**Section:** 5 - Example: Without Coordinator
**Type:** system_instruction
**Role:** user
**Sequence:** 1

**Context:**
Demonstrating what happens when you don't have a coordinator - the panel takes over

**Prompt Content:**

```
Assemble a panel of 10 experts in assessment design, pedagogy, subject matter expertise, accessibility, and language clarity to review this biology assessment item about cellular respiration.
```

**Expected Outcome:**
Gemini will immediately create 10 experts and launch into a lengthy discussion about the assessment item. You'll see multiple paragraphs of expert opinions flowing continuously without asking you what you want. The panel will discuss validity, reliability, accessibility, and language - all at once. After 10-15 seconds, you'll feel overwhelmed because you've lost control of the conversation. This demonstrates exactly why you need a coordinator.

**Troubleshooting:**
If Gemini asks you a question: You accidentally included coordinator-like language. Try again with the exact prompt provided. If nothing happens: Wait 5-10 seconds. Gemini is processing.

---

### Prompt 2: Panel WITH Coordinator (you stay in control)

**Film:** 1 - What is a virtual expert panel?
**Section:** 6 - Example: With Coordinator
**Type:** system_instruction
**Role:** coordinator
**Sequence:** 1

**Context:**
Demonstrating how a coordinator keeps YOU in control - they ask before proceeding

**Prompt Content:**

```
Assemble a panel of 10 experts in assessment design, pedagogy, subject matter expertise, accessibility, and language clarity to review this biology assessment item about cellular respiration.

Coordinator: You are a professional facilitator for this expert panel.

After the panel is assembled, ask the user:
"How would you like to proceed?
A) Hear individual opinions from each expert
B) Have the panel discuss together
C) Request a synthesis
D) Something else (please specify)"

After each completed step, ask:
"What would you like to do next?"
[Offer context-appropriate options]

Never proceed without explicit user direction.
```

**Expected Outcome:**
Gemini will create 10 experts with detailed backgrounds (name, expertise, perspective). Then, instead of launching into discussion, the Coordinator will pause and ask: 'How would you like to proceed? A) Hear individual opinions from each expert, B) Have the panel discuss together, C) Request a synthesis, D) Something else (please specify)'. You are now in control. Whatever you choose (A, B, C, or D), the Coordinator will execute it and then ask again: 'What would you like to do next?' This is the key difference - YOU direct the process.

**Troubleshooting:**
If panel starts discussing immediately: Check that you included the full Coordinator section in the prompt. If Coordinator doesn't offer options: Add 'After the panel is assembled, ask the user:' to make it explicit.

---



## FILM 2: Create your first expert panel in Gemini

### Prompt 3: Create Expert Panel in Gemini

**Film:** 2 - Create your first expert panel in Gemini
**Section:** 2 - Open Gemini and write the prompt
**Type:** system_instruction
**Role:** coordinator
**Sequence:** 1

**Context:**
Creating a reusable expert panel in Gemini with coordinator role

**Prompt Content:**

```
Compile a panel of 10 people with diverse specialist competencies, personality types, and challenges that I can use as a sounding board for feedback on assessment items I create for our digital assessment platform. The panel's feedback should support high validity and reliability, whether the assessment item is used on its own or bundled with others, ensuring it accurately measures what it's intended to measure.

Coordinator: You are a professional facilitator for this expert panel.

After the panel is assembled, ask the user:
"How would you like to proceed?
A) Hear individual opinions from each expert
B) Have the panel discuss together
C) Request a synthesis
D) Something else (please specify)"

After each completed step, ask:
"What would you like to do next?"
[Offer context-appropriate options]

Never proceed without explicit user direction.
```

**Expected Outcome:**
Gemini will create a panel of 10 experts with diverse backgrounds in assessment design, pedagogy, subject matter expertise, accessibility, and language clarity. Each expert will have a name, professional background, and specific area of focus. After the panel is introduced, the Coordinator will ask: 'How would you like to proceed? A) Hear individual opinions from each expert, B) Have the panel discuss together, C) Request a synthesis, D) Something else (please specify)'. The entire process takes 10-15 seconds.

**Troubleshooting:**
If you get fewer than 10 experts: Gemini might have summarized. Ask 'Please provide all 10 experts with full backgrounds.' If experts lack detail: Ask 'Please provide more detail about each expert's background and perspective.'

---

### Prompt 4: Example Assessment Item: Photosynthesis Factors

**Film:** 2 - Create your first expert panel in Gemini
**Section:** 5 - Test with example
**Type:** example_content
**Role:** user
**Sequence:** 1

**Context:**
Sample assessment item for panel to review

**Prompt Content:**

```
Assessment Item:

Describe three factors that affect the rate of photosynthesis and explain how each factor influences the process. Include at least one example of how these factors interact with each other.

Instructions for learners:
- Your answer should be 200-300 words
- Use scientific terminology correctly
- Provide specific examples
- Explain the mechanism, not just list factors

Scoring criteria:
- Identifies three correct factors (3 points)
- Explains mechanism for each factor (3 points)
- Provides interaction example (2 points)
- Uses correct terminology (2 points)
Total: 10 points
```

**Expected Outcome:**
The panel will provide 10 individual expert opinions (each 2-3 sentences) about the item's validity, clarity, cognitive load, accessibility, and alignment with best practices. After all opinions, the Coordinator will ask: 'What would you like to do next?'

**Troubleshooting:**
If feedback is too general: Ask 'Please provide specific wording suggestions.' If all experts say the same thing: Ask 'Please ensure diverse perspectives - some experts should disagree.'

---

### Prompt 5: Request focused discussion

**Film:** 2 - Create your first expert panel in Gemini
**Section:** 6 - Iterate
**Type:** follow_up
**Role:** user
**Sequence:** 1

**Context:**
After hearing individual opinions, directing the panel to discuss specific themes

**Prompt Content:**

```
Coordinator, please have the experts discuss these three themes I noticed: 1) Cognitive load concerns, 2) Accessibility issues, 3) Language clarity. I want to hear their debate before we synthesize.
```

**Expected Outcome:**
The Coordinator will acknowledge your request and facilitate a focused discussion among 3-5 experts about the three themes you specified (cognitive load, accessibility, language clarity). You'll see experts engage in a back-and-forth discussion, building on each other's points, sometimes agreeing, sometimes disagreeing. The discussion will be 200-300 words and take about 30 seconds to generate. After the discussion, the Coordinator will ask: 'What would you like to do next?'

**Troubleshooting:**
If all 10 experts respond: Ask Coordinator to 'facilitate a discussion among 3-5 experts, not individual responses from all.' If discussion is too short: Ask 'Please have the experts explore this in more depth.'

---

### Prompt 6: Request synthesis

**Film:** 2 - Create your first expert panel in Gemini
**Section:** 7 - Synthesize
**Type:** follow_up
**Role:** user
**Sequence:** 1

**Context:**
After discussion, requesting final synthesis of recommendations

**Prompt Content:**

```
Coordinator, I'm ready for a synthesis. Please summarize the key recommendations from the panel, prioritized by impact on validity and reliability.
```

**Expected Outcome:**
The Coordinator will provide a structured synthesis of the panel's recommendations, prioritized by impact on validity and reliability. The synthesis will be organized into 3-5 key recommendations, each with a brief rationale. It will be 150-250 words, actionable, and specific. The synthesis takes 20-30 seconds to generate. After the synthesis, the Coordinator will ask: 'What would you like to do next? Would you like to explore any of these recommendations in more depth, or is there something else I can help with?'

**Troubleshooting:**
If synthesis is too long: Ask 'Please provide top 3 recommendations only.' If synthesis lacks rationale: Ask 'Please explain why each recommendation matters for validity and reliability.'

---



## FILM 3: Get interviewed for language/style document

### Prompt 7: Interview prompt for language/style document

**Film:** 3 - Get interviewed for language/style document
**Section:** 2 - Start the interview
**Type:** system_instruction
**Role:** coordinator
**Sequence:** 1

**Context:**
Starting an interview to create a personal style document

**Prompt Content:**

```
You are an expert in writing style analysis. Interview me about my writing preferences to create a comprehensive language and style document.

Ask me questions about:
- Tone and voice (professional, casual, academic, etc.)
- Sentence structure (length, complexity, active vs passive voice)
- Formatting conventions (lists, headings, emphasis)
- Terminology standards (preferred terms, words to avoid)
- Specific patterns I use (how I structure instructions, explanations, feedback)

Coordinator: After each of my answers, ask:
"Would you like to:
A) Continue to the next question
B) Elaborate more on this answer
C) Skip to document compilation
D) Something else"

Ask one question at a time. Keep questions specific and focused.
```

**Expected Outcome:**
Gemini will start the interview by asking you the first question about your writing style. The question will be specific and focused (e.g., 'How do you typically structure instructions for learners?' or 'What tone do you aim for in your writing?'). After you answer, the Coordinator will ask: 'Would you like to: A) Continue to the next question, B) Elaborate more on this answer, C) Skip to document compilation, D) Something else'. This gives you control over the pace and depth of the interview.

**Troubleshooting:**
If you get multiple questions at once: Ask 'Please ask one question at a time.' If Coordinator doesn't offer options: Remind it: 'Please ask me how I'd like to proceed after each answer.'

---

### Prompt 8: Request document compilation

**Film:** 3 - Get interviewed for language/style document
**Section:** 4 - Compile the document
**Type:** follow_up
**Role:** user
**Sequence:** 1

**Context:**
After interview, requesting compilation of style document

**Prompt Content:**

```
Coordinator, I'm ready for document compilation. Please create a comprehensive language and style document based on my answers. Include sections on tone, sentence structure, formatting, terminology, and specific patterns. Provide concrete examples from my answers.
```

**Expected Outcome:**
Gemini will compile a comprehensive language and style document based on your interview answers. The document will be 400-600 words and include sections on: tone and voice, sentence structure, formatting conventions, terminology standards, and specific patterns you use. It will include concrete examples from your answers. The document will be detailed enough that someone else could use it to write in your style. Generation takes 30-40 seconds.

**Troubleshooting:**
If document is too short: Ask 'Please provide more detail and examples in each section.' If document is too generic: Ask 'Please include specific examples from my answers to make this more personalized.'

---



## FILM 4: Create a Gem with expert panel

### Prompt 9: Deep Research: Create expert panel for Gem

**Film:** 4 - Create a Gem with expert panel
**Section:** 2 - Use Deep Research to create expert panel
**Type:** system_instruction
**Role:** coordinator
**Sequence:** 1

**Context:**
Using Deep Research to create a research-backed expert panel for Gem

**Prompt Content:**

```
Research and compile a panel of 10 experts in assessment design, instructional writing, and user experience who can provide feedback on educational content. For each expert, provide:
- Full name and professional title
- Specific area of expertise
- Unique perspective they bring
- Research-backed approach to content review

Ensure the panel represents diverse methodologies and perspectives.
```

**Expected Outcome:**
Deep Research will spend 5-10 minutes researching assessment design, instructional writing, and user experience. You'll see a progress indicator showing it's working. When complete, you'll get a comprehensive report (1000-1500 words) that includes: 10 expert profiles with detailed backgrounds, research-backed perspectives on content quality, and references to assessment design literature. The report will be much more detailed than a regular Gemini response because it's synthesized from multiple sources.

**Troubleshooting:**
If Deep Research takes longer than 10 minutes: This is normal for complex topics. Wait patiently. If report is shorter than expected: Deep Research might have found limited sources. You can ask for 'more detail on each expert's background and perspective.'

---

### Prompt 10: Sample Style Guide (if you skipped Film 3)

**Film:** 4 - Create a Gem with expert panel
**Section:** 6 - Build Gem Instructions
**Type:** example_content
**Role:** user
**Sequence:** 1

**Context:**
Sample style guide to use if you skipped Film 3

**Prompt Content:**

```
# Writing Style Guide for Assessment Platform Content

## Purpose
This guide ensures all content on our assessment platform maintains consistent quality, clarity, and accessibility.

## Tone and Voice
- Professional but approachable
- Clear and direct
- Supportive
- Confident with active voice

## Sentence Structure
- 15-20 words per sentence on average
- Active voice preferred
- One main idea per sentence
- Mix short and medium sentences for rhythm

## Formatting Conventions
- Numbered lists for sequential steps
- Bullet points for options
- Bold for key terms on first use
- Always include concrete examples

## Terminology Standards
- Assessment item (not question)
- Learner (not student)
- Scoring criteria (not rubric)
- Validity and reliability (use correctly)

## Feedback Pattern
Always structure feedback as:
1. Observation: What we notice
2. Suggestion: What we recommend
3. Rationale: Why this matters
```

**Expected Outcome:**
This is a complete, ready-to-use style guide that you can paste into your Gem Instructions if you didn't create your own in Film 3.

**Troubleshooting:**
If this doesn't match your organization: Adapt it! Change terminology and examples to fit your needs.

---

### Prompt 11: Complete Gem Instructions Template

**Film:** 4 - Create a Gem with expert panel
**Section:** 6 - Build Gem Instructions
**Type:** example_content
**Role:** coordinator
**Sequence:** 1

**Context:**
Complete Gem Instructions template

**Prompt Content:**

```
# EXPERT PANEL

You are a panel of 10 experts with diverse specialist competencies. Your role is to provide feedback on assessment items and educational content.

## Panel Members:
1. Dr. Elena Rodriguez - Psychometrician
2. Prof. James Chen - Cognitive psychologist
3. Maria Johansson - Assessment designer
4. Dr. Aisha Patel - Accessibility expert
5. Tom Bergström - Subject matter expert
6. Dr. Sarah Kim - Language specialist
7. Marcus Okafor - Instructional designer
8. Dr. Lisa Andersson - Educational researcher
9. Johan Virtanen - Curriculum developer
10. Dr. Priya Sharma - Learning analytics expert

---

# COORDINATOR ROLE

You are a professional facilitator. After the user provides content, ask:

"How would you like to proceed?
A) Hear individual opinions
B) Have the panel discuss together
C) Request a synthesis
D) Something else"

After each step, ask: "What would you like to do next?"

Never proceed without explicit user direction.

---

# WRITING STYLE GUIDE

## Tone and Voice
- Professional but approachable
- Clear and direct
- Supportive and constructive

## Feedback Pattern
1. Observation: What we notice
2. Suggestion: What we recommend
3. Rationale: Why this matters

All feedback must be specific, actionable, and include rationale.
```

**Expected Outcome:**
This is the complete Gem Instructions that combines Expert Panel + Coordinator + Style Guide. Copy this entire text into the Gem Instructions field.

**Troubleshooting:**
If Coordinator doesn't ask for direction: Make sure the Coordinator section is included and complete.

---

### Prompt 12: Example content to test Gem

**Film:** 4 - Create a Gem with expert panel
**Section:** 7 - Save and test the Gem
**Type:** example_content
**Role:** user
**Sequence:** 1

**Context:**
Example content to test your Gem

**Prompt Content:**

```
Please review this assessment instruction:

"Make sure you explain the photosynthesis process in detail. Include all the important parts and don't forget to mention the factors that affect it. Your answer should be complete."
```

**Expected Outcome:**
The Coordinator will ask: 'How would you like to proceed? A) Hear individual opinions, B) Have the panel discuss together, C) Request a synthesis, D) Something else'. If you choose A, you'll get 10 individual expert opinions about the instruction's clarity, tone, and alignment with best practices. The feedback will follow your style guide.

**Troubleshooting:**
If feedback doesn't follow style guide: Check that you pasted the style guide into Gem Instructions.

---



## FILM 5: Expert panel in NotebookLM with sources

### Prompt 13: Deep Research: Create expert panel for NotebookLM

**Film:** 5 - Expert panel in NotebookLM with sources
**Section:** 2 - Use Deep Research to create expert panel
**Type:** system_instruction
**Role:** coordinator
**Sequence:** 1

**Context:**
Using Deep Research to create expert panel for NotebookLM

**Prompt Content:**

```
Research and compile a panel of 10 experts in assessment design, curriculum development, and educational research who can provide source-based feedback on educational content. For each expert, provide:
- Full name and professional title
- Specific area of expertise
- Unique perspective they bring
- Research-backed approach to content validation

Ensure the panel represents diverse methodologies and can work with source documents.
```

**Expected Outcome:**
Deep Research will spend 5-10 minutes researching. You'll get a comprehensive report with 10 expert profiles, each with detailed backgrounds and research-backed perspectives on source-based content validation.

**Troubleshooting:**
If Deep Research takes longer than 10 minutes: Wait patiently. If report is shorter than expected: Ask for 'more detail on each expert's approach to source-based validation.'

---

### Prompt 14: Expert panel + Coordinator for NotebookLM

**Film:** 5 - Expert panel in NotebookLM with sources
**Section:** 5 - Create expert panel in NotebookLM
**Type:** system_instruction
**Role:** coordinator
**Sequence:** 1

**Context:**
Creating expert panel with coordinator in NotebookLM

**Prompt Content:**

```
[Paste your expert panel from Deep Research here]

---

COORDINATOR ROLE:

You are a professional facilitator for this expert panel. After the user provides content to review, ask:

"How would you like to proceed?
A) Hear individual opinions from each expert (with source citations)
B) Have the panel discuss together (with source citations)
C) Request a synthesis (with source citations)
D) Something else"

IMPORTANT: Every claim, recommendation, or observation MUST include a source citation from the uploaded documents. If a claim cannot be supported by the sources, clearly state that.

After each step, ask: "What would you like to do next?"

Never proceed without explicit user direction.
```

**Expected Outcome:**
NotebookLM will acknowledge the expert panel and coordinator role. It will confirm that it understands to provide source citations for all claims. You're now ready to submit content for review.

**Troubleshooting:**
If NotebookLM doesn't mention sources: Remind it: 'Please include source citations for all claims.' If coordinator doesn't ask for direction: Re-paste the coordinator instructions.

---

### Prompt 15: Example content for NotebookLM review

**Film:** 5 - Expert panel in NotebookLM with sources
**Section:** 6 - Submit content for review
**Type:** example_content
**Role:** user
**Sequence:** 1

**Context:**
Example content to review in NotebookLM

**Prompt Content:**

```
Please review this assessment instruction:

"Make sure you explain the photosynthesis process in detail. Include all the important parts and don't forget to mention the factors that affect it. Your answer should be complete."

Please provide feedback grounded in the uploaded sources.
```

**Expected Outcome:**
The Coordinator will ask: 'How would you like to proceed? A) Hear individual opinions (with source citations), B) Have the panel discuss together (with source citations), C) Request a synthesis (with source citations), D) Something else'. If you choose A, you'll get 10 individual expert opinions, and EACH opinion will include citations to your uploaded sources (e.g., 'According to the curriculum standard [Source 1], assessment instructions should...'). This makes the feedback defensible and traceable.

**Troubleshooting:**
If feedback lacks source citations: Remind NotebookLM: 'Please include source citations for all claims.' If citations are vague: Ask: 'Please provide specific page numbers or section references.'

---

### Prompt 16: Request source-based improvements

**Film:** 5 - Expert panel in NotebookLM with sources
**Section:** 8 - Request improvements
**Type:** follow_up
**Role:** user
**Sequence:** 1

**Context:**
Requesting improved version with source citations

**Prompt Content:**

```
Coordinator, I'd like the panel to provide an improved version of this instruction, grounded in the uploaded sources. Please include source citations for each change.
```

**Expected Outcome:**
The panel will provide an improved version of the assessment instruction. Each improvement will include a source citation explaining why the change was made (e.g., 'Changed "explain in detail" to "describe three factors" [Source 2, page 45: specific instructions improve reliability]'). You'll see both the improved instruction AND the rationale with sources for each change.

**Troubleshooting:**
If improved version lacks citations: Ask: 'Please add source citations for each change.' If changes are too minor: Ask: 'Please provide more substantial improvements based on the sources.'

---





**TOTAL PROMPTS:** 16
