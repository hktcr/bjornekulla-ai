# SEMINAR QUESTIONS

This document contains all reflection and discussion questions for the final seminar.

The seminar is where transformation happens. Technical skills are learned in films + exercises. Mindset shift happens in the seminar.

---

## AFTER FILM 1: What is a virtual expert panel?

**[PERSONAL]** What task from your daily work did you identify? What makes it challenging?

**[EXPERTISE]** What expertise do you currently lack that would help you do it better?

**[TIME]** How much time do you spend on tasks where you need feedback or validation?

**[ROLES]** In your chosen task, who would be the Experts (👥)? What perspectives would they bring?

**[COORDINATOR]** What would the Coordinator (🎯) need to do to make the panel discussion productive?

**[CONDUCTOR]** As the Conductor (👤), what control do you want to maintain?

**[MINDSET]** Before this workshop, how did you think about AI tools? (Helper? Replacement? Threat? Tool?)

**[METAPHOR]** How does the 'conductor' metaphor change your perspective?

**[DIFFERENCE]** What's the difference between 'asking AI a question' and 'conducting an expert panel'?

**[PREFERENCE]** For your chosen task, would you prefer: Individual expert opinions? Panel discussion? Synthesis/summary? Something else?

---

## AFTER FILM 2: Create your first expert panel in Gemini

**[DOMAIN]** What domain did you create your panel for? (Development, leadership, content, design, support, sales, communication, other?)

**[TIME]** How long did it take to create the panel? Was it faster or slower than expected?

**[CONTENT]** What content did you test it with? (Code, strategy doc, course material, design, guide, email, etc.)

**[QUALITY]** How was the quality of feedback compared to what you usually get?

**[INSIGHTS]** Did the panel identify issues you hadn't thought of?

**[BLINDSPOTS]** Were there any 'blind spots' the panel missed?

**[INTERACTION]** Which interaction mode worked best for you? (Individual opinions, discussion, synthesis)

**[COORDINATOR]** How did the coordinator role affect the process?

**[CONTROL]** Did you feel in control? What would you change?

**[ROI_TIME]** How long did the panel review take vs. your usual process?

**[ROI_WEEKLY]** If you used this weekly, how much time would you save?

**[ROI_USAGE]** What would you do with that saved time?

---

## AFTER FILM 3: Get interviewed for language/style document

**[DOMAIN]** What domain did you create your style document for?

**[EXPERIENCE]** How did it feel to be interviewed by AI? Weird? Natural? Helpful?

**[ARTICULATION]** Did the interview questions help you articulate things you hadn't put into words before?

**[ACCURACY]** Does the style document accurately capture YOUR voice/approach/principles?

**[QUALITY]** What did it get right? What did it miss?

**[EFFORT]** Would you have been able to write this document yourself? How long would it have taken?

**[DISCOVERY]** Did the interview help you discover or clarify your own preferences?

**[INSIGHT]** Were there questions that made you think differently about your work?

**[LEARNING]** Did you learn something about yourself?

**[APPLICATION]** How will you use this style document? (Gem, NotebookLM, team onboarding, personal reference?)

**[TEAM]** Who else in your team/organization could benefit from creating their own style document?

**[IMPACT]** What would happen if everyone in your team had their style documented?

---

## AFTER FILM 4: Create a Gem with expert panel

**[CREATION]** What Gem did you create? (Domain + purpose)

**[SETUP]** How long did it take to set up?

**[COMPARISON]** How does the feedback from your Gem compare to the generic panel in Film 2?

**[STYLE]** Does the Gem's feedback reflect YOUR style/principles/voice?

**[CONSISTENCY]** Is it consistent across multiple uses?

**[TRUST]** Would you trust this Gem to review your work before sharing with others?

**[ROI_TIME]** How long does a review with your Gem take vs. your usual process?

**[ROI_FREQUENCY]** How many reviews do you do per week?

**[ROI_WEEKLY]** How much time will you save per week? Per year?

**[ROI_TOTAL]** What's the ROI in weeks/months of work saved per year?

**[BARRIERS]** What barriers exist to using this regularly?

**[ADOPTION]** What would make you use it every day?

**[SCALING]** Who else in your organization should create their own Gem?

---

## AFTER FILM 5: Expert panel in NotebookLM with sources

**[CREATION]** What NotebookLM notebook did you create? (Domain + sources)

**[COMPARISON]** How does source-based feedback differ from your Gem (Film 4)?

**[CITATIONS]** Did the citations surprise you? Were they accurate?

**[DEFENSIBILITY]** Can you now defend your work decisions with specific sources?

**[CONVERSATIONS]** How does this change conversations with stakeholders/managers/clients?

**[VALUE]** What's the value of being able to say 'According to [Source 2, page 45]...'?

**[QUALITY]** Did the sources catch issues your Gem missed?

**[INSIGHTS]** Did the sources provide new insights you hadn't considered?

**[CONFIDENCE]** How does evidence-based feedback change your confidence in the output?

**[ROI_RESEARCH]** How much time do you currently spend finding evidence/sources to support your decisions?

**[ROI_WEEKLY]** How much time will NotebookLM save you per week?

**[ROI_TOTAL]** What's the total ROI across all three tools (Gemini panel, Gem, NotebookLM)?

**[TRANSFORMATION]** How has your relationship with AI changed from Film 1 to Film 5?

**[CONDUCTOR]** Do you feel like a 'conductor' now? What does that mean to you?

**[ACTION]** What will you do differently in your work starting tomorrow?

---

## FINAL SEMINAR: Synthesis & Reflection

### Opening Questions (10 minutes)
1. Quick round: What's ONE thing you'll start using tomorrow?
2. What surprised you most about this workshop?

### Three Roles Deep Dive (15 minutes)
3. How has the 'Three Roles' concept changed how you think about AI?
4. In your daily work, when do you need Experts (👥)? Coordinator (🎯)? When do you need to be Conductor (👤)?
5. What's the difference between 'using AI' and 'conducting AI'?

### Human Role (15 minutes)
6. **The big question:** What's YOUR role as a human now that you can conduct expert panels?
7. What can you do that AI cannot? (Even with perfect prompts and sources?)
8. How does your value change when you have access to expert panels?
9. Are you more valuable or less valuable? Why?

### Organizational Impact (15 minutes)
10. If everyone in your organization could conduct expert panels, what would change?
11. What new possibilities open up?
12. What risks or challenges do you foresee?
13. How would you introduce this to your team/organization?

### Personal Transformation (15 minutes)
14. How much time will you save per week using these tools?
15. What will you do with that time? (More work? Different work? Better work?)
16. How does this change your career trajectory?
17. What skills become more important? What skills become less important?

### Final Reflection (10 minutes)
18. Complete this sentence: 'Before this workshop, I thought AI was ___. Now I think AI is ___.'
19. What's the most important insight you're taking away?
20. What's your next step?

---

**FACILITATOR NOTE:**
The seminar should feel like a conversation, not an interrogation. Use these questions as guides, but follow the energy and interests of the group. The goal is transformation, not completion of a checklist.
