# TECHNICAL SETUP INSTRUCTIONS

This document provides step-by-step instructions for accessing and setting up all tools needed for the workshop.

---

## REQUIRED TOOLS

You will need access to three Google tools:

1. **Google Gemini** - For creating expert panels and Gems
2. **Google NotebookLM** - For source-based content review
3. **Google Gem Manager** - For creating permanent expert panels

All tools are free to use with a Google account.

---

## 1. ACCESSING GOOGLE GEMINI

### What is Gemini?
Gemini is Google's AI assistant. You'll use it to create virtual expert panels and test prompts.

### How to access:
1. Open your web browser
2. Go to: **[gemini.google.com](https://gemini.google.com)**
3. Sign in with your Google account
4. You should see a chat interface

### Verify access:
Type "Hello" and press Enter. If Gemini responds, you're ready!

### Troubleshooting:
- **"Gemini isn't available in your country"** - You may need to use a VPN or wait for availability
- **"You need to join the waitlist"** - Gemini is now generally available; try signing out and back in
- **Can't sign in** - Make sure you're using a Google Workspace or personal Google account

### Tips:
- **Use Deep Research:** When creating expert panels, click "Deep Research" before sending your prompt for better results
- **Start new chats:** Create a new chat for each exercise to avoid confusion
- **Save important outputs:** Copy and paste important responses to a Google Doc

---

## 2. ACCESSING GOOGLE NOTEBOOKLM

### What is NotebookLM?
NotebookLM is Google's AI research assistant that works with your sources. You'll use it in Film 5 for source-based content review.

### How to access:
1. Open your web browser
2. Go to: **[notebooklm.google.com](https://notebooklm.google.com)**
3. Sign in with your Google account
4. Click "New notebook" to create your first notebook

### Verify access:
If you see the notebook interface with "Add sources" button, you're ready!

### Troubleshooting:
- **"NotebookLM isn't available yet"** - It's rolling out globally; check back in a few days
- **Can't create notebook** - Make sure you're signed in with a Google account
- **Sources won't upload** - Try smaller files (under 10MB) or different formats (PDF, TXT, DOCX)

### Tips:
- **Upload your style guide:** This is the key source for Film 5
- **Use the chat:** Ask NotebookLM questions about your sources
- **Try Audio Overview:** NotebookLM can create a podcast-style discussion of your sources (optional but cool!)

---

## 3. ACCESSING GEM MANAGER

### What is Gem Manager?
Gem Manager lets you create permanent, reusable AI assistants (Gems) with custom instructions. You'll create your expert panel Gem in Film 4.

### How to access:
1. Open Gemini: **[gemini.google.com](https://gemini.google.com)**
2. Look for "Gem manager" in the top right corner (icon looks like a gem 💎)
3. Click "Gem manager"
4. Click "Create new Gem"

### Verify access:
If you see the Gem creation interface with "Name," "Description," and "Instructions" fields, you're ready!

### Troubleshooting:
- **Can't find Gem Manager** - It may be under a menu icon (three dots) in the top right
- **"Gems aren't available"** - This feature is rolling out; you may need to wait
- **Can't save Gem** - Make sure all required fields are filled in

### Tips:
- **Test your Gem:** After creating, test it with example content before using it for real work
- **Iterate:** You can edit your Gem anytime to improve it
- **Share:** You can share Gems with colleagues (optional)

---

## 4. UPLOADING SOURCES TO NOTEBOOKLM

### Step-by-step:
1. Open your NotebookLM notebook
2. Click "Add sources" (or the "+" button)
3. Choose source type:
   - **Upload file:** For your style guide document (PDF, DOCX, TXT)
   - **Google Drive:** If your style guide is in Google Docs
   - **Website:** If you have online documentation
   - **Copy-paste:** For shorter text content
4. Wait for processing (usually 10-30 seconds)
5. Verify: Your source should appear in the "Sources" panel on the left

### Supported formats:
- **Documents:** PDF, DOCX, TXT, MD
- **Presentations:** PPTX (converted to text)
- **Spreadsheets:** XLSX, CSV (data is extracted)
- **Web:** Any public URL
- **Google Drive:** Docs, Sheets, Slides

### File size limits:
- **Maximum file size:** 10MB per file
- **Maximum total:** 50 sources per notebook
- **Text length:** Up to 500,000 words total

### Tips:
- **Upload your style guide from Film 3** as the primary source
- **Add example content** (assessment items, emails, etc.) as additional sources
- **Upload company documentation** if you want NotebookLM to align with company standards

---

## 5. CREATING A GEM (DETAILED)

### Step-by-step:
1. **Open Gem Manager**
   - Go to gemini.google.com
   - Click "Gem manager" (top right)
   - Click "Create new Gem"

2. **Fill in basic information:**
   - **Name:** "Assessment Expert Panel" (or relevant to your domain)
   - **Description:** "Expert panel for reviewing assessment items with coordinator and style guide"

3. **Add Instructions:**
   - Paste the Complete Gem Instructions Template from File 07_EXAMPLE_CONTENT.md
   - OR paste your custom instructions from Film 4

4. **Add Knowledge (optional but recommended):**
   - Upload your style guide document
   - Upload example content
   - Upload company documentation

5. **Save and test:**
   - Click "Save"
   - Click "Chat with this Gem"
   - Test with example content

### What goes in "Instructions" vs "Knowledge":
- **Instructions:** HOW the Gem should behave (expert panel, coordinator, style guide)
- **Knowledge:** WHAT the Gem should know about (your documents, examples, company info)

### Tips:
- **Start simple:** Use the template first, customize later
- **Test thoroughly:** Try different types of content before using for real work
- **Iterate:** Edit and improve based on results

---

## 6. SYSTEM REQUIREMENTS

### Minimum requirements:
- **Browser:** Chrome, Firefox, Safari, or Edge (latest version)
- **Internet:** Stable connection (at least 5 Mbps)
- **Google account:** Personal or Workspace account
- **Screen:** At least 1280x720 resolution (for comfortable viewing)

### Recommended:
- **Browser:** Chrome (best compatibility with Google tools)
- **Internet:** 10+ Mbps for smooth experience
- **Screen:** 1920x1080 or larger (for side-by-side viewing)
- **Second monitor:** Optional but helpful for following along with films while working

### Mobile:
- Gemini and NotebookLM work on mobile, but the workshop is designed for desktop/laptop
- If using mobile, use tablet (iPad, Android tablet) rather than phone

---

## 7. PRE-WORKSHOP CHECKLIST

Before starting the workshop, verify:

- [ ] I can access Gemini at gemini.google.com
- [ ] I can access NotebookLM at notebooklm.google.com
- [ ] I can access Gem Manager in Gemini
- [ ] I have a Google account signed in
- [ ] I have stable internet connection
- [ ] I have prepared content to test with (assessment items, emails, code, etc.)
- [ ] I have 3 hours available without interruptions
- [ ] I have a way to take notes (Google Docs, Notion, etc.)

---

## 8. DURING WORKSHOP TIPS

### Browser setup:
- **Two windows side-by-side:**
  - Left: Workshop interface (or films)
  - Right: Gemini/NotebookLM for exercises
- **OR use two monitors** if available

### Saving your work:
- **Create a Google Doc** titled "Workshop Notes [Your Name] [Date]"
- **Copy important outputs** from Gemini and NotebookLM to this doc
- **Save your style guide** from Film 3 (you'll need it in Films 4 and 5)
- **Bookmark your Gem** after creating it in Film 4

### Troubleshooting during workshop:
- **Gemini not responding:** Refresh the page and try again
- **NotebookLM source won't upload:** Try a different format or smaller file
- **Gem not behaving as expected:** Check that Instructions were pasted correctly
- **Lost your work:** Check your Google Doc or Gemini chat history

---

## 9. POST-WORKSHOP SETUP

After completing the workshop, you'll have:

1. **A Gem** - Bookmark it or add to favorites for easy access
2. **A NotebookLM notebook** - Keep it for ongoing use
3. **Your style guide** - Save in Google Drive for reference
4. **Workshop notes** - Review and organize for future reference

### Next steps:
- **Test your Gem daily** for one week with real work content
- **Refine your style guide** based on what works
- **Share with colleagues** (optional)
- **Integrate into workflow** - Make it a habit, not a one-time thing

---

## 10. TROUBLESHOOTING COMMON ISSUES

### "I can't access Gemini"
- **Check availability:** Gemini may not be available in all countries yet
- **Try VPN:** If in unsupported country
- **Check account:** Make sure you're using a Google account
- **Clear cache:** Try incognito/private browsing mode

### "NotebookLM won't upload my file"
- **Check file size:** Must be under 10MB
- **Check format:** PDF, DOCX, TXT, MD are best
- **Try Google Drive:** Upload to Google Docs first, then link from NotebookLM
- **Try copy-paste:** For shorter documents, paste directly

### "My Gem isn't working as expected"
- **Check Instructions:** Make sure they were pasted correctly
- **Test with example:** Try the example from 07_EXAMPLE_CONTENT.md first
- **Simplify:** Start with simpler instructions, add complexity gradually
- **Recreate:** Sometimes starting fresh helps

### "I'm stuck during an exercise"
- **Ask the Gem/Gemini:** Describe what you're trying to do and ask for help
- **Check the prompts:** Make sure you copied the full prompt
- **Try a different approach:** If option A doesn't work, try option B
- **Take a break:** Sometimes stepping away for 5 minutes helps

---

## SUPPORT RESOURCES

### Official documentation:
- **Gemini Help:** [support.google.com/gemini](https://support.google.com/gemini)
- **NotebookLM Help:** [support.google.com/notebooklm](https://support.google.com/notebooklm)

### During workshop:
- **Ask the Workshop Facilitator Gem:** It can help troubleshoot
- **Check the knowledge base:** Files 01-07 in this package

### After workshop:
- **Test with examples first:** Use 07_EXAMPLE_CONTENT.md
- **Iterate gradually:** Don't expect perfection on first try
- **Share learnings:** Help colleagues who get stuck

---

**Remember:** The tools are just tools. The real value is in the Three Roles framework and how YOU use it to stay in control.

