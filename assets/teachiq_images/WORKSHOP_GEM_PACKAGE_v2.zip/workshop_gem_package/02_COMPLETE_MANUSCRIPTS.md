# COMPLETE MANUSCRIPTS - ALL 5 FILMS

This document contains the complete voice-over manuscripts for all 5 workshop films.

---

## FILM 1: What is a virtual expert panel?

**Estimated length:** 6 min

### Section 1: The Problem

**Type:** intro
**Duration:** 0:20

**Manuscript:**

You're working on a complex assessment item for your digital assessment platform. You need multiple perspectives: pedagogical design, subject matter expertise, accessibility considerations, language clarity. But you don't have time to consult everyone individually. Sound familiar?

**Notes:** Pro tip: Start with a relatable problem that your colleagues face daily. This creates immediate engagement.

---

### Section 2: Tool Introduction

**Type:** explanation
**Duration:** 1:30

**Manuscript:**

Before we dive into the three roles, let's quickly introduce the three Google AI tools we'll use in this workshop. Don't worry about mastering them now - we'll explore each one in detail in the upcoming films.

**Gemini** (30 seconds)
Gemini is Google's conversational AI. Think of it as a knowledgeable colleague you can chat with. You type questions or requests, and Gemini responds. It's fast, flexible, and perfect for quick iterations. In Film 2, you'll use Gemini to create your first expert panel.

**Deep Research** (30 seconds)
Deep Research is a feature within Gemini that conducts thorough, multi-source research on a topic. Instead of giving you a quick answer, it spends 5-10 minutes analyzing multiple perspectives and synthesizing findings. It's perfect for creating well-grounded expert panels. We'll use it in Films 4 and 5.

**NotebookLM** (30 seconds)
NotebookLM is Google's source-based AI tool. You upload documents - like curriculum standards, style guides, or research papers - and NotebookLM answers questions based on those sources. Every response includes citations. It's perfect for when you need defensible, traceable feedback. We'll explore it in Film 5.

Now, with these tools in mind, let's talk about the three roles that make expert panels work.

**Notes:** Pro tip: Show each tool's interface on screen while describing it. Keep tempo calm - 90 seconds is enough time.

---

### Section 3: The Solution: Expert Panel

**Type:** explanation
**Duration:** 0:30

**Manuscript:**

What if you could assemble a virtual expert panel in seconds? A virtual expert panel is a group of AI-simulated experts, each with specific expertise, who can review your work and provide diverse perspectives. It's like having a team of consultants available 24/7.

**Notes:** Pro tip: Show the speed and convenience. Open Gemini and demonstrate how quick it is to create a panel.

---

### Section 4: The Three Roles

**Type:** explanation
**Duration:** 2:00

**Manuscript:**

A well-designed expert panel has three essential roles, and understanding these is key to using panels effectively.

First, the Experts (👥): They provide specialized knowledge and diverse perspectives. Each expert brings their unique lens to your problem.

Second, the Coordinator (🎯): This is crucial. The coordinator facilitates the process and asks YOU how to proceed. They don't make decisions for you, they help you lead the discussion.

Third, You - The Conductor (👤): YOU are in control. You decide when to hear individual opinions, when to have discussions, and when to synthesize. Think of yourself as a conductor leading an orchestra. The coordinator is your concert master, helping you communicate with the musicians.

**Notes:** Pro tip: Use the orchestra metaphor throughout. It's memorable and accurate. Show three icons: 👥 Experts, 🎯 Coordinator, 👤 You.

---

### Section 5: Example: Without Coordinator

**Type:** demo
**Duration:** 0:30

**Manuscript:**

Let's see what happens without a coordinator. Watch carefully. I'm asking for an expert panel to review an assessment item, but I haven't included a coordinator role.

**Notes:** Pro tip: Show the panel immediately launching into a long discussion. Let it run for 10-15 seconds, then pause and say 'Notice how I've lost control? The panel is discussing without asking me what I want. This is overwhelming.'

---

### Section 6: Example: With Coordinator

**Type:** demo
**Duration:** 1:30

**Manuscript:**

Now let's see the same scenario with a coordinator. Notice the difference immediately.

**Notes:** Pro tip: Show the coordinator asking 'How would you like to proceed?' Then show yourself choosing option A (individual opinions). Let a few opinions appear, then show the coordinator asking again. Choose option B (discussion). Show how YOU are in control the entire time.

---

### Section 7: Practical Application

**Type:** explanation
**Duration:** 0:40

**Manuscript:**

In the next films, you'll learn how to create and use expert panels in Gemini for quick iterations, save them as Gems for repeated use, and integrate them with NotebookLM for source-based analysis. But always remember these three roles: You are the conductor. The coordinator helps you lead. The experts provide insight. This isn't about letting AI take over, it's about you staying in control while leveraging AI's capabilities.

**Notes:** Pro tip: Show all three icons together one more time. Reinforce the conductor metaphor. Estimated time saved per week: 5-10 hours for content developers.

---

### Section 8: Call to Action

**Type:** outro
**Duration:** 0:10

**Manuscript:**

Ready to create your first expert panel with a coordinator? Let's move to Film 2 where you'll do exactly that in Gemini.

**Notes:** Pro tip: Keep energy high. Transition smoothly to Film 2.

---



## FILM 2: Create your first expert panel in Gemini

**Estimated length:** 6 min

### Section 1: Opening

**Type:** intro
**Duration:** 30 sec

**Manuscript:**

In this video, we'll create your first virtual expert panel directly in Gemini. If you haven't seen Film 1 about the three roles (Experts 👥, Coordinator 🎯, Conductor 👤), watch that first - it's essential context.

Quick reminder: Experts provide insight, Coordinator facilitates, and YOU conduct. Let's see this in action.

You'll need: a Gemini account, about 10 minutes, and an example of an assessment item or content you want feedback on.

Let's get started.

**Notes:** Pro tip: Have a real example ready before starting - it makes the demo more concrete

---

### Section 2: Open Gemini and write the prompt

**Type:** demo
**Duration:** 90 sec

**Manuscript:**

First, I open Gemini. Now I'm going to write a prompt that creates an expert panel for reviewing assessment items.

Remember from Film 1: we need experts, a coordinator, and you as the conductor. Let me show you how to include all three roles in the prompt.

Here's my prompt:

**Notes:** Pro tip: Asking for 'diverse personality types' ensures you get different perspectives, not just agreement

---

### Section 3: Wait for response

**Type:** demo
**Duration:** 30 sec

**Manuscript:**

Now Gemini is creating the panel. Notice how the coordinator is included in the prompt. As we saw in Film 1, the coordinator will ask me how I want to proceed after the panel is created.

This keeps me in control of the process.

---

### Section 4: Review the panel

**Type:** demo
**Duration:** 40 sec

**Manuscript:**

Great! The panel is created and the coordinator is asking me how I want to proceed. I'm going to choose option A: hear individual opinions first.

This way I can see what each expert thinks before they discuss together. I stay in control.

**Notes:** Show coordinator asking 'How would you like to proceed?' and you choosing option A

---

### Section 5: Test with example

**Type:** demo
**Duration:** 30 sec

**Manuscript:**

Now I'll paste an assessment item for the panel to review. Watch how I direct the process.

**Notes:** Pro tip: Paste the full item including instructions, question, and scoring criteria for complete feedback

---

### Section 6: Iterate

**Type:** demo
**Duration:** 60 sec

**Manuscript:**

After hearing individual opinions, the coordinator asks me again: what's next? Now I'm going to ask for a discussion among the experts about the key themes I noticed.

**Notes:** Pro tip: Notice how I'm directing the process, not just letting it run on autopilot

---

### Section 7: Synthesize

**Type:** demo
**Duration:** 50 sec

**Manuscript:**

The discussion is complete. The coordinator asks me again: what's next? Now I'm ready for a synthesis.

**Notes:** Pro tip: Ask for specific, actionable suggestions rather than general feedback

---

### Section 8: Save the conversation

**Type:** demo
**Duration:** 30 sec

**Manuscript:**

When you're done, make sure to save this conversation. You can return to it later and continue the discussion with the same panel.

However, this panel only exists in this conversation. If you want to reuse it across multiple conversations, you need to make it a Gem. That's what we'll do in Film 4.

**Notes:** Pro tip: Name your conversation something descriptive like 'Assessment Review Panel' for easy finding later

---

### Section 9: Closing

**Type:** outro
**Duration:** 40 sec

**Manuscript:**

You've now created your first expert panel in Gemini with a coordinator. You've seen how the three roles work together: the experts (👥) provide insight, the coordinator (🎯) facilitates, and YOU (👤) direct the process.

This workflow takes 5 minutes. Manual review by multiple colleagues would take 2-3 hours and require scheduling meetings. Time saved per review: 2+ hours. For 10 reviews per week, that's 20+ hours saved.

In the next film, we'll create a language and style document by having Gemini interview you. This document will be used in Films 4 and 5 to ensure all content matches your voice.

See you in the next film.

---



## FILM 3: Get interviewed for language/style document

**Estimated length:** 7 min

### Section 1: Opening

**Type:** intro
**Duration:** 30 sec

**Manuscript:**

In this film, you'll create a personal language and style document by letting Gemini interview you about your writing preferences.

This document will be used in Films 4 and 5 to ensure all AI-generated content matches YOUR voice and style.

You'll need: a Gemini account, about 10 minutes, and honest reflection about how you write.

Let's get started.

**Notes:** Pro tip: Emphasize that this is about THEIR voice, not a generic style guide

---

### Section 2: Start the interview

**Type:** demo
**Duration:** 60 sec

**Manuscript:**

I'm opening Gemini and starting a new conversation. Now I'll paste a prompt that asks Gemini to interview me about my writing style.

Notice that I'm including the coordinator role again - this ensures I stay in control of the interview process.

**Notes:** Pro tip: The coordinator ensures you can elaborate or skip ahead at any time

---

### Section 3: Answer questions

**Type:** demo
**Duration:** 90 sec

**Manuscript:**

Gemini is asking me about my writing style. I'm going to answer honestly and specifically.

Notice how I'm giving examples, not just descriptions. Instead of saying 'I use clear language,' I say 'I use clear language by avoiding jargon. For example, I write "use" instead of "utilize".'

This specificity makes the final document much more useful.

**Notes:** Pro tip: Show yourself answering 2-3 questions with specific examples

---

### Section 4: Compile the document

**Type:** demo
**Duration:** 60 sec

**Manuscript:**

After answering 5-6 questions, I feel I've given enough information. The coordinator is asking me what I want to do next.

I'm going to choose option C: skip to document compilation.

Now I'll ask Gemini to compile everything into a comprehensive style document.

**Notes:** Pro tip: Save this document - you'll use it in Films 4 and 5

---

### Section 5: Review the document

**Type:** demo
**Duration:** 50 sec

**Manuscript:**

Here's my personal style document. Notice how it includes specific examples from my answers.

Let me scroll through it. See how it captures my tone preferences, sentence structure, formatting conventions, and specific patterns I use. This is detailed enough that someone else could use it to write in my style.

Now, let me show you exactly what to do with this document.

**Notes:** Pro tip: Show the document on screen and highlight key sections. Scroll slowly so viewers can read.

---

### Section 6: How to use this document

**Type:** explanation
**Duration:** 70 sec

**Manuscript:**

This is important - here's exactly what you'll do with your style document:

**Step 1: Save it now**
Copy the entire document and save it in Google Docs. Name it 'My Writing Style Guide' or something similar. You'll need this file in the next two films.

**Step 2: In Film 4 (Gem)**
When you create your Gem, you'll paste this style document directly into the Gem Instructions field. I'll show you exactly where. This makes your Gem always write in YOUR style.

**Step 3: In Film 5 (NotebookLM)**
When you create your NotebookLM notebook, you'll upload this style document as one of your sources. I'll show you exactly how. This makes NotebookLM's feedback align with YOUR preferences.

**The result:** Instead of generic AI feedback, you get feedback that sounds like it's coming from someone who knows your style intimately. That's the power of this document.

So right now, save this document. You'll use it in 10 minutes.

**Notes:** Pro tip: Show Google Docs interface. Emphasize 'save it NOW' - don't let them forget. Show the document being saved.

---

### Section 7: Closing

**Type:** outro
**Duration:** 50 sec

**Manuscript:**

You've now created a personal language and style document. This took about 10 minutes.

Without AI, creating such a document would require hours of self-reflection and writing. Many people never do it because it's too time-consuming.

But now you have a document that captures YOUR voice. In Film 4, we'll use this to create a Gem that always writes in your style. In Film 5, we'll use it in NotebookLM for source-based content review.

See you in the next film.

---



## FILM 4: Create a Gem with expert panel

**Estimated length:** 7 min

### Section 1: Opening

**Type:** intro
**Duration:** 30 sec

**Manuscript:**

In this film, we'll create a Gem - a reusable AI assistant that combines an expert panel, coordinator, and your personal style guide from Film 3.

Gems are perfect for workflows you repeat often. Instead of pasting the same prompt every time, you create a Gem once and reuse it across conversations.

You'll need: Gemini account, your style document from Film 3 (or use the sample provided), and about 15 minutes.

Let's get started.

**Notes:** Pro tip: Emphasize REUSABILITY - Gems save time on repeated workflows

---

### Section 2: Use Deep Research to create expert panel

**Type:** demo
**Duration:** 60 sec

**Manuscript:**

First, I'll use Deep Research to create a well-grounded expert panel. Deep Research takes 5-10 minutes, but it produces much more detailed and research-backed expert profiles than regular Gemini.

I'm opening Gemini and pasting this Deep Research prompt.

**Notes:** Pro tip: Show Deep Research progress indicator. Mention this is a good time for a coffee break.

---

### Section 3: Wait for Deep Research

**Type:** demo
**Duration:** 20 sec

**Manuscript:**

Deep Research is working now. This takes 5-10 minutes because it's analyzing multiple sources and synthesizing findings.

This is a good time for a coffee break. When you do this yourself, you can work on something else while Deep Research runs.

[Fast-forward in video]

Deep Research is done! Let me review the report.

**Notes:** Pro tip: Fast-forward this section in the video. Show progress indicator, then jump to completion.

---

### Section 4: Review Deep Research report

**Type:** demo
**Duration:** 40 sec

**Manuscript:**

Here's the Deep Research report. Notice how detailed the expert profiles are compared to regular Gemini. Each expert has a full background, specific expertise, and research-backed perspective.

I'm going to copy this entire expert panel description. I'll use it in my Gem Instructions.

**Notes:** Pro tip: Show scrolling through the report. Highlight the detail level.

---

### Section 5: Open Gem Manager

**Type:** demo
**Duration:** 40 sec

**Manuscript:**

Now I'll create the Gem. I'm opening Gem Manager in Gemini's left sidebar.

I click 'Create new Gem' and name it 'Content Review Assistant'.

Now comes the important part: the Gem Instructions field. This is where I combine three components: the expert panel from Deep Research, the coordinator role, and my style guide from Film 3.

**Notes:** Pro tip: Show Gem Manager interface clearly. Show naming the Gem.

---

### Section 6: Build Gem Instructions

**Type:** demo
**Duration:** 90 sec

**Manuscript:**

In the Instructions field, I'm pasting three things in order:

First: The expert panel description from Deep Research.

Second: The coordinator instructions. This ensures I stay in control.

Third: My style guide from Film 3. If you skipped Film 3, use the Sample Style Guide provided in the interface.

Here's what the complete Gem Instructions look like.

**Notes:** Pro tip: Show pasting all three components. Emphasize the order: Panel → Coordinator → Style.

---

### Section 7: Save and test the Gem

**Type:** demo
**Duration:** 60 sec

**Manuscript:**

I click 'Save'. My Gem is now created.

Let's test it. I open a new conversation and select my 'Content Review Assistant' Gem.

Now I'll paste some example content to review.

**Notes:** Pro tip: Show Coordinator asking. Show yourself choosing option A.

---

### Section 8: Review Gem feedback

**Type:** demo
**Duration:** 50 sec

**Manuscript:**

Perfect! The Coordinator asked me how to proceed. I chose option A: individual opinions.

Notice how the feedback follows my style guide. It's professional but approachable. Each suggestion includes a rationale.

This is the power of Gems: consistent, reusable workflows that match YOUR voice.

**Notes:** Pro tip: Highlight specific examples of style guide being followed.

---

### Section 9: Closing

**Type:** outro
**Duration:** 40 sec

**Manuscript:**

You've now created a Gem with an expert panel, coordinator, and your style guide. This Gem is reusable across all your conversations.

Time to create this Gem: 15 minutes (including Deep Research). Time per review after that: 2 minutes. For 10 reviews per week, that's 20+ hours saved compared to manual review.

In the next film, we'll use NotebookLM to add source-based validation with citations.

See you in the next film.

**Notes:** Pro tip: Emphasize ROI - 2 minutes per review after setup.

---



## FILM 5: Expert panel in NotebookLM with sources

**Estimated length:** 8 min

### Section 1: Opening

**Type:** intro
**Duration:** 40 sec

**Manuscript:**

In this final film, we'll use NotebookLM to create an expert panel that's grounded in YOUR sources. This is perfect for when you need defensible, traceable feedback with citations.

The difference from Gems: NotebookLM provides source citations for every claim. This is critical for quality assurance, compliance, and defensibility.

You'll need: NotebookLM account, source documents (curriculum standards, research papers, or style guides), and about 20 minutes.

Let's get started.

**Notes:** Pro tip: Emphasize TRACEABILITY - every claim has a source citation

---

### Section 2: Use Deep Research to create expert panel

**Type:** demo
**Duration:** 60 sec

**Manuscript:**

Just like in Film 4, I'll start with Deep Research to create a well-grounded expert panel. This ensures the panel is research-backed, not just invented.

I'm opening Gemini and pasting the Deep Research prompt.

**Notes:** Pro tip: Show Deep Research progress. Mention coffee break again.

---

### Section 3: Wait and review Deep Research

**Type:** demo
**Duration:** 30 sec

**Manuscript:**

[Fast-forward]

Deep Research is done. I'm reviewing the expert panel. Notice how each expert has expertise in working with source documents and research literature.

I'm copying this entire panel description. I'll use it in NotebookLM.

**Notes:** Pro tip: Fast-forward wait time. Show scrolling through report.

---

### Section 4: Open NotebookLM and upload sources

**Type:** demo
**Duration:** 60 sec

**Manuscript:**

Now I'm opening NotebookLM and creating a new notebook. I'll name it 'Content Review with Sources'.

The key difference from Gems: I need to upload source documents. These could be curriculum standards, research papers, style guides, or any documents you want the panel to reference.

I'm uploading three sources: a curriculum standard, a research paper on assessment design, and my style guide from Film 3.

**Notes:** Pro tip: Show uploading sources clearly. Mention supported formats (PDF, Docs, web pages).

---

### Section 5: Create expert panel in NotebookLM

**Type:** demo
**Duration:** 60 sec

**Manuscript:**

Now I'll paste the expert panel description from Deep Research into NotebookLM's chat.

Then I'll add the coordinator instructions to ensure I stay in control of the review process.

**Notes:** Pro tip: Emphasize that EVERY claim needs a source citation.

---

### Section 6: Submit content for review

**Type:** demo
**Duration:** 40 sec

**Manuscript:**

Now I'll submit some content for the panel to review. I'm using the same example from Film 4 so you can compare the difference.

**Notes:** Pro tip: Show yourself pasting the content. Wait for Coordinator to ask.

---

### Section 7: Review source-based feedback

**Type:** demo
**Duration:** 70 sec

**Manuscript:**

Perfect! The Coordinator asked me how to proceed. I chose option A: individual opinions with source citations.

Notice the difference from Film 4: Every suggestion now includes a source citation. For example: 'According to the curriculum standard [Source 1, page 12], assessment instructions should specify expected length and format.'

This makes the feedback defensible. If someone questions a recommendation, you can point to the exact source.

**Notes:** Pro tip: Highlight source citations clearly. Show clicking on citation to see source.

---

### Section 8: Request improvements

**Type:** demo
**Duration:** 60 sec

**Manuscript:**

Now I'll ask the Coordinator for the next step. I want to see how the panel would improve this instruction, grounded in the sources.

**Notes:** Pro tip: Show the improved instruction with citations for each change.

---

### Section 9: Review improved version

**Type:** demo
**Duration:** 50 sec

**Manuscript:**

Here's the improved instruction with source citations for each change. This is incredibly powerful for quality assurance.

If my manager asks 'Why did you change this?', I can point to the exact source: 'According to Smith et al. [Source 2, page 45], specific instructions improve scoring reliability.'

This level of traceability is what separates NotebookLM from Gems.

**Notes:** Pro tip: Show the improved instruction side-by-side with original. Highlight citations.

---

### Section 10: Closing

**Type:** outro
**Duration:** 60 sec

**Manuscript:**

You've now used NotebookLM to create source-based expert feedback. This is perfect for quality assurance, compliance, and defensibility.

Time investment: 20 minutes (including Deep Research and source upload). Time per review after that: 10 minutes. For source-based validation that would normally take 1-2 hours of manual work, this is a massive time saver.

When to use Gems vs NotebookLM:
- Gems: Fast, flexible, consistent style. Use for routine content review.
- NotebookLM: Source-based, traceable, defensible. Use for quality assurance and compliance.

You now have a complete AI toolkit for content review. Thank you for participating in this workshop.

**Notes:** Pro tip: Emphasize the Gems vs NotebookLM decision framework.

---



