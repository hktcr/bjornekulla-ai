# PAUSE & TASK ACTIVITIES

This document contains all hands-on exercises that participants complete between films.

---

## AFTER FILM 1: What is a virtual expert panel?

### Pause & Task: Reflect on your work

**Duration:** 5 minutes

**Task:**
Think about a task you do regularly that requires multiple perspectives or expertise you don't have: Developers (code review, architecture decisions, debugging), Leadership (strategic decisions, risk analysis, stakeholder communication), Content creators (writing, editing, quality assurance), Designers (UX feedback, accessibility review, design critique), Support (troubleshooting guides, FAQ creation, customer communication), Sales/Marketing (pitch decks, customer emails, campaign copy), Communication (press releases, internal announcements, crisis communication).

**Steps:**
- Identify a task from YOUR daily work that needs multiple perspectives
- Write down: 1) What task did you choose? 2) What expertise would you need? 3) How long does it take?
- Keep this task in mind - you'll use it in Film 2

**Expected Output:**
You have identified a specific task from your work and understand what expertise you need

**Reflection Questions:**
- What task did you choose? What makes it challenging?
- What expertise do you currently lack?
- How much time do you spend on tasks where you need feedback or validation?

---

## AFTER FILM 2: Create your first expert panel in Gemini

### Pause & Task: Create your panel and test with YOUR content

**Duration:** 25 minutes

**Task:**
Create your own expert panel in Gemini for a task relevant to YOUR role. Examples: Developers (API design review), Leadership (restructuring proposal), Content creators (course outline review), Designers (user flow critique), Support (troubleshooting guide review), Sales (pitch deck review), Communication (press release review).

**Steps:**
- Open Gemini
- Use the coordinator prompt (adapt the example to your domain)
- Create your panel (10-15 minutes)
- Test it with real content from your work (10-15 minutes)
- Try different interaction modes (individual opinions, discussion, synthesis)

**Expected Output:**
You have created a functional expert panel and tested it with real content from your work

**Reflection Questions:**
- What worked well? What surprised you?
- How long did it take compared to your usual process?
- What would you change for next time?

---

## AFTER FILM 3: Get interviewed for language/style document

### Pause & Task: Create YOUR style document

**Duration:** 20 minutes

**Task:**
Let Gemini interview you to create a style document for YOUR domain. Examples: Developers (code style, documentation preferences, review criteria), Leadership (communication style, decision-making frameworks, leadership principles), Content creators (writing voice, pedagogical approach, quality standards), Designers (design principles, aesthetic preferences, UX philosophy), Support (tone of voice, troubleshooting approach, customer interaction style), Sales (pitch style, objection handling, relationship-building approach), Communication (brand voice, messaging framework, crisis communication principles).

**Steps:**
- Use the interview prompt (adapt to your domain)
- Answer 8-10 questions honestly (15-20 minutes)
- Review the generated style document
- Save it to Google Docs or notes (name it 'My [Domain] Style Guide')
- IMPORTANT: You'll use this in Film 4 and 5!

**Expected Output:**
You have a 3-4 page style document that captures YOUR voice/approach/principles for your domain

**Reflection Questions:**
- Does the style document accurately capture YOUR voice/approach/principles?
- What did it get right? What did it miss?
- Would you have been able to write this yourself? How long would it have taken?

---

## AFTER FILM 4: Create a Gem with expert panel

### Pause & Task: Create YOUR Gem

**Duration:** 20 minutes

**Task:**
Create your own Gem with expert panel + coordinator + your style document. Examples: Developers ('Code Review Assistant'), Leadership ('Strategy Advisor'), Content creators ('Content Quality Coach'), Designers ('UX Critique Partner'), Support ('Support Guide Creator'), Sales ('Pitch Reviewer'), Communication ('Message Crafter').

**Steps:**
- Open Gemini Gems
- Create new Gem
- Paste expert panel prompt (from Film 2)
- Paste coordinator instructions
- Paste your style document (from Film 3)
- Name your Gem
- Test it with real content (10 minutes)

**Expected Output:**
You have a permanent, reusable Gem that provides feedback in YOUR style

**Reflection Questions:**
- How long did it take to create the Gem?
- How does the feedback compare to Film 2 (without style document)?
- How much time will this save you per week?

---

## AFTER FILM 5: Expert panel in NotebookLM with sources

### Pause & Task: Create YOUR NotebookLM expert panel

**Duration:** 25 minutes

**Task:**
Create a source-based expert panel in NotebookLM for YOUR domain. Examples: Developers (API docs + best practices + code style → review code), Leadership (company strategy + industry reports + leadership principles → review decisions), Content creators (curriculum standards + research papers + style guide → review content), Designers (design systems + accessibility guidelines + design philosophy → review designs), Support (product docs + support best practices + tone guide → review support content), Sales (sales methodology + customer case studies + pitch style → review proposals), Communication (brand guidelines + crisis frameworks + brand voice → review messages).

**Steps:**
- Open NotebookLM
- Create new notebook
- Upload 3-5 relevant sources (PDFs, docs, links)
- Use the expert panel prompt (adapted to your domain)
- Test with real content (15 minutes)
- Check citations - do they point to your sources?

**Expected Output:**
You have a source-based expert panel that provides evidence-backed feedback with citations

**Reflection Questions:**
- How does source-based feedback differ from Gem feedback?
- Can you defend your decisions with citations?
- How much time will this save you?

---

