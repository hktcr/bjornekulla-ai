# ABOUT THE FILMS

This document explains how the films fit into the workshop and what to do if you don't have access to them.

---

## WORKSHOP STRUCTURE

The workshop consists of:

1. **5 short films** (2-7 minutes each, 34 minutes total)
2. **5 hands-on exercises** (10-20 minutes each, 85 minutes total)
3. **1 final seminar** (30-45 minutes)

**Total time:** 2.5-3 hours

---

## THE FILMS

### Film 1: What is a virtual expert panel? (2-3 min)
**Purpose:** Introduces the Three Roles framework (👥 Experts, 🎯 Coordinator, 👤 You)

**Key concepts:**
- You're the conductor, not the audience
- Virtual expert panels vs single AI
- The orchestrator metaphor

**What you'll do after:** Create your first expert panel in Gemini

---

### Film 2: Create your first expert panel in Gemini (6 min)
**Purpose:** Shows how to create a one-time expert panel using Deep Research

**Key concepts:**
- Deep Research for comprehensive panels
- Coordinator role for control
- Testing with real content

**What you'll do after:** Create your own panel and test with YOUR content

---

### Film 3: The Interview - Creating YOUR style document (7 min)
**Purpose:** Shows how to create a personal style guide through AI interview

**Key concepts:**
- AI interviews YOU to understand your style
- 8-10 questions about tone, structure, quality
- Results in 3-4 page style document

**What you'll do after:** Complete the interview and save your style document

---

### Film 4: Create a permanent Gem (10 min)
**Purpose:** Shows how to create a reusable expert panel as a Gem

**Key concepts:**
- Gems = permanent, reusable AI assistants
- Combining expert panel + coordinator + style guide
- Testing and iterating

**What you'll do after:** Create your own Gem with your style

---

### Film 5: NotebookLM - Source-based expert panel (9 min)
**Purpose:** Shows how to use NotebookLM for source-based review with citations

**Key concepts:**
- NotebookLM works with YOUR sources
- Citations and defensibility
- Audio Overview feature

**What you'll do after:** Create NotebookLM notebook with your style guide

---

## IF YOU DON'T HAVE ACCESS TO THE FILMS

The films are helpful but not strictly required. The Workshop Facilitator Gem can guide you through without them.

### Alternative approach:

**Instead of watching films, read:**
- **02_COMPLETE_MANUSCRIPTS.md** - Contains all voice-over scripts
- **01_WORKSHOP_OVERVIEW_AND_PURPOSE.md** - Explains key concepts

**Then follow along with:**
- **Workshop Facilitator Gem** - Guides you through exercises
- **03_ALL_PROMPTS.md** - All prompts with context
- **04_PAUSE_AND_TASK_ACTIVITIES.md** - All exercises

### Time adjustment:
- **With films:** 2.5-3 hours total
- **Without films (reading instead):** 3-3.5 hours total (reading takes slightly longer)

---

## FILM RECORDING NOTES (FOR FACILITATORS)

These films will be recorded based on the manuscripts in 02_COMPLETE_MANUSCRIPTS.md.

### Recording setup:
- **Screen recording:** OBS or similar
- **Voice-over:** Based on manuscript sections
- **On-screen demonstrations:** Follow the prompts and show real results
- **Timing:** Follow duration estimates in manuscripts

### Key principles:
- **Show, don't just tell:** Demonstrate each step on screen
- **Use real content:** Don't use fake examples
- **Show mistakes:** If something doesn't work perfectly, show how to fix it
- **Pause for copy:** When showing prompts, pause long enough for viewers to copy

### Technical specs:
- **Resolution:** 1920x1080 minimum
- **Frame rate:** 30fps minimum
- **Audio:** Clear voice-over, minimal background noise
- **Captions:** Recommended for accessibility

---

## USING THE WORKSHOP WITHOUT FILMS

If you're using the Workshop Facilitator Gem without films, here's the recommended flow:

### 1. Start conversation with Gem:
"Hi, I'd like to go through the workshop. I don't have access to the films, so I'll be reading the manuscripts instead. I'm a [your role] and I want to learn how to use virtual expert panels for [your use case]."

### 2. Gem will guide you through:
- Reading relevant sections from manuscripts
- Completing exercises at the right time
- Answering seminar questions
- Troubleshooting if you get stuck

### 3. Follow this sequence:
1. Read Film 1 manuscript (02_COMPLETE_MANUSCRIPTS.md, Film 1)
2. Complete Exercise 1 (04_PAUSE_AND_TASK_ACTIVITIES.md, Film 1)
3. Read Film 2 manuscript
4. Complete Exercise 2
5. ... and so on

### 4. Key difference:
- **With films:** Passive watching, then active doing
- **Without films:** Active reading, then active doing
- **Result:** Same learning outcomes, slightly longer time

---

## FREQUENTLY ASKED QUESTIONS

### "Do I need to watch the films in order?"
**Yes.** Each film builds on the previous one. Film 3 creates the style guide you need for Films 4 and 5.

### "Can I skip a film?"
**Not recommended,** but if you must:
- **Film 1:** Don't skip - this explains the whole framework
- **Film 2:** Don't skip - this is your first hands-on practice
- **Film 3:** Can skip IF you use the sample style guide from 07_EXAMPLE_CONTENT.md
- **Film 4:** Don't skip - this creates your permanent tool
- **Film 5:** Could skip, but you'll miss the source-based approach

### "Can I watch films later and do exercises now?"
**Not recommended.** Films provide context and demonstrations that make exercises much easier.

### "How long are the films?"
- Film 1: 2-3 min
- Film 2: 6 min
- Film 3: 7 min
- Film 4: 10 min
- Film 5: 9 min
- **Total: 34 minutes**

### "Are the films available online?"
**To be determined.** Check with your workshop facilitator for access.

### "Can I use the manuscripts instead of films?"
**Yes!** See "IF YOU DON'T HAVE ACCESS TO THE FILMS" section above.

---

## FOR WORKSHOP FACILITATORS

### If hosting live workshop:
- **Show films to group:** Project on screen, everyone watches together
- **Pause after each film:** Give time for exercises
- **Encourage discussion:** Use seminar questions between films

### If participants are self-paced:
- **Provide film links:** Or manuscript access
- **Provide Gem access:** Share the Workshop Facilitator Gem
- **Provide support:** Be available for questions

### If recording your own films:
- **Use manuscripts:** 02_COMPLETE_MANUSCRIPTS.md as your script
- **Show real demonstrations:** Don't fake it
- **Include your own examples:** Adapt to your organization's context
- **Test first:** Record a test version and review before final

---

## ACCESSIBILITY NOTES

### For participants with visual impairments:
- **Manuscripts are screen-reader friendly:** All content in 02_COMPLETE_MANUSCRIPTS.md
- **Prompts are text-based:** Easy to copy-paste with screen readers
- **Gem is voice-compatible:** Can use voice input with Gemini

### For participants with hearing impairments:
- **Manuscripts contain all content:** No audio-only information
- **Captions recommended:** If films are available, add captions
- **Text-based exercises:** All exercises are text-based

### For participants with cognitive differences:
- **Take your time:** No rush, workshop is self-paced
- **Break it up:** Do one film per day if needed
- **Use Gem for help:** Ask questions anytime
- **Simplify:** Start with simpler content, build up gradually

---

## SUMMARY

**Films are helpful but not required.** The complete workshop experience is available through:
1. **Films** (recommended) - Visual demonstrations
2. **Manuscripts** (alternative) - Written scripts
3. **Workshop Facilitator Gem** (required) - Guides you through everything

**Choose the approach that works best for you!**

